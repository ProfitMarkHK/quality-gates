# pyservice — agent notes

This is a small internal HTTP service written in Python.

## Layout
- `src/pyservice/` — package source
- `tests/` — pytest suite

## Conventions
- Use type hints on all public functions.
- Keep functions small and pure where possible.
