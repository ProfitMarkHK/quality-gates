# web-dashboard

Internal analytics dashboard (TypeScript).

## Getting started
- `npm install`
- `npm run build`

## Code style
- Prefer named exports.
- No `any` unless justified with a comment.
